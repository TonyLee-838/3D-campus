import React from 'react';
import SuspenseWrapper from '../../basic/SuspenseWrapper';
import BackWindows from './BackWindows';
import Ceiling from './Ceiling';
import Floor from './Floor';
import FrontWall from './FrontWall';
import LeftWall from './LeftWall';
import RightWall from './RightWall';

const Layout = () => {
  return (
    <>
      {/* <LeftWall /> */}
      <Floor />
      {/* <Ceiling scale={[0.5, 0.5, 0.5]} position={[0, 1, 0]} /> */}
      {/* <BackWindows />
      <FrontWall />
      <Floor />
    <RightWall /> */}
    </>
  );
};

export default Layout;
