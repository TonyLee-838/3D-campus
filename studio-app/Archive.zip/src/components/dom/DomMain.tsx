import React from "react";
import { FpsView } from "react-fps";
import Aim from "./Aim";

const DomMain = () => {
  return (
    <>
      <FpsView />
    </>
  );
};

export default DomMain;
