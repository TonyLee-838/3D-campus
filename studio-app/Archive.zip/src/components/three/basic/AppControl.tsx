import React from "react";

import FirstPersonalControl from "./FirstPersonControl";

const AppControl = () => {
  return (
    <>
      <FirstPersonalControl />
    </>
  );
};

export default AppControl;
