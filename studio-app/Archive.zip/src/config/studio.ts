// distance between player and his/her target object
export const DISTANCE = 2.5;

// maximun distance which player can far away from suitable circle
export const SUITABLE_RADIUS = 0.5;

export const PLAYER_HEIGHT = 1.75;
