const colors = {
  primary: '#1976d2',
  green: '#3EB735',
  white: '#ffffff',
};

export default colors;
